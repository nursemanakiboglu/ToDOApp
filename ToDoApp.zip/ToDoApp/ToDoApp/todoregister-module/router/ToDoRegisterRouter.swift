//
//  ToDoRegisterRouter.swift
//  ToDoApp
//
//  Created by Nursema Nakiboğlu on 10.06.2022.
//

import Foundation

class ToDoRegisterRouter : PresenterToRouterToDoRegisterProtocol {
    static func createModule(ref: ToDoRegisterVC) {
        ref.toDoRegisterPresenterObject = ToDoRegisterPresenter()
        ref.toDoRegisterPresenterObject?.toDoRegisterInteractor = ToDoRegisterInteractor()
    }
}
