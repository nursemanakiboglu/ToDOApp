//
//  ToDoRegisterProtocols.swift
//  ToDoApp
//
//  Created by Nursema Nakiboğlu on 10.06.2022.
//

import Foundation

protocol ViewToPresenterToDoRegisterProtocol {
    var toDoRegisterInteractor:PresenterToInteractorToDoRegisterProtocol? {get set}
    func register(todo_content:String)
}

protocol PresenterToInteractorToDoRegisterProtocol {
    func toDoRegister(todo_content:String)
}

protocol PresenterToRouterToDoRegisterProtocol {
    static func createModule(ref:ToDoRegisterVC)
}
