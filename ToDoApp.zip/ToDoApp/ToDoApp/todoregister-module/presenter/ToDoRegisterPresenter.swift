//
//  ToDoRegisterPresenter.swift
//  ToDoApp
//
//  Created by Nursema Nakiboğlu on 10.06.2022.
//

import Foundation

class ToDoRegisterPresenter : ViewToPresenterToDoRegisterProtocol {
    var toDoRegisterInteractor: PresenterToInteractorToDoRegisterProtocol?
    
    func register(todo_content: String) {
        toDoRegisterInteractor?.toDoRegister(todo_content: todo_content)
    }
}
