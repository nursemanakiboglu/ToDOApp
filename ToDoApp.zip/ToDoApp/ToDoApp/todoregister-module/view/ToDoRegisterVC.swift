//
//  ToDoRegisterVC.swift
//  ToDoApp
//
//  Created by Nursema Nakiboğlu on 10.06.2022.
//

import UIKit

class ToDoRegisterVC: UIViewController {

    @IBOutlet weak var tfToDo: UITextField!
    
    var toDoRegisterPresenterObject:ViewToPresenterToDoRegisterProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ToDoRegisterRouter.createModule(ref: self)
      
    }
    
    @IBAction func buttonAdd(_ sender: Any) {
        if let todo = tfToDo.text {
            toDoRegisterPresenterObject?.register(todo_content: todo)
        }
    }
    
}
