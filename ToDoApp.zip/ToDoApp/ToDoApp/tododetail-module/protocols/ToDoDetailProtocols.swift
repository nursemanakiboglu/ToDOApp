//
//  ToDoDetailProtocols.swift
//  ToDoApp
//
//  Created by Nursema Nakiboğlu on 10.06.2022.
//

import Foundation

protocol ViewToPresenterToDoDetailProtocol {
    var toDoDetailInteractor:PresenterToInteractorToDoDetailProtocol? {get set}
    
    func update(todo_id:Int,todo_content:String)
}

protocol PresenterToInteractorToDoDetailProtocol {
    func toDoUpdate(todo_id:Int,todo_content:String)
}

protocol PresenterToRouterToDoDetailProtocol {
    static func createModule(ref:ToDoDetailVC)
}
