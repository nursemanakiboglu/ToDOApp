//
//  ToDoDetailRouter.swift
//  ToDoApp
//
//  Created by Nursema Nakiboğlu on 10.06.2022.
//

import Foundation

class ToDoDetailRouter : PresenterToRouterToDoDetailProtocol {
    static func createModule(ref: ToDoDetailVC) {
        ref.toDoDetailPresenterObject = ToDoDetailPresenter()
        ref.toDoDetailPresenterObject?.toDoDetailInteractor = ToDoDetailInteractor()
    }
}
