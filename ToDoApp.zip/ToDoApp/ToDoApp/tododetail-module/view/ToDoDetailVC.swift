//
//  ToDoDetailVC.swift
//  ToDoApp
//
//  Created by Nursema Nakiboğlu on 10.06.2022.
//

import UIKit

class ToDoDetailVC: UIViewController {

    @IBOutlet weak var tfToDo: UITextField!
    
    var toDo:ToDos?
    var toDoDetailPresenterObject:ViewToPresenterToDoDetailProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let t = toDo {
            tfToDo.text = t.todo_content
        }
        
        ToDoDetailRouter.createModule(ref: self)
    }
    
    @IBAction func buttonUpdate(_ sender: Any) {
        if let tc = tfToDo.text, let t = toDo {
            toDoDetailPresenterObject?.update(todo_id: t.todo_id!, todo_content: tc)
        }
    }

}
